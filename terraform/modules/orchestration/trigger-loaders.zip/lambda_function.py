#!/usr/bin/env python3
"""Lambda function to manually trigger data loaders via ECS.

Called when EventBridge fails or for emergency data refresh.
Invoked by: API /api/algo/trigger-loader endpoint or CloudWatch alarm
Uses LambdaHandler base class for standardized pattern.
"""

import logging
import os
import sys
from datetime import datetime, timezone
from typing import Any

import boto3

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from base_handler import LambdaHandler, LambdaResponse, create_lambda_handler

logger = logging.getLogger()


class TriggerLoadersHandler(LambdaHandler):
    """Triggers ECS loader tasks."""

    def _validate_stock_scores_dependencies(self) -> tuple[bool, str]:
        """Validate that upstream metric loaders are ready before triggering stock_scores.

        Returns: (is_valid, error_message) tuple.
        is_valid=True means dependencies are met and stock_scores can proceed.
        is_valid=False means dependencies missing; error_message explains why.
        """
        try:
            # Import here to avoid circular dependency
            from utils.db.context import DatabaseContext

            with DatabaseContext("read") as cur:
                cur.execute("""
                    SELECT table_name, completion_pct, status
                    FROM data_loader_status
                    WHERE table_name IN ('value_metrics', 'positioning_metrics', 'stability_metrics')
                    AND last_updated >= CURRENT_TIMESTAMP - INTERVAL '1 hour'
                """)

                metric_status = cur.fetchall()
                if not metric_status:
                    return False, "No recent metric loader status found. Metric loaders may not have run yet."

                # Check that critical metrics have >= 90% completion
                min_coverage_pct = 90.0
                for table_name, completion_pct, _status in metric_status:
                    if completion_pct is None:
                        return (
                            False,
                            f"Metric loader {table_name} status unclear (completion_pct is NULL). "
                            f"Wait for loader to complete before triggering stock_scores."
                        )

                    if completion_pct < min_coverage_pct:
                        return (
                            False,
                            f"Metric loader {table_name} only {completion_pct:.1f}% complete. "
                            f"Wait for >= {min_coverage_pct}% completion before triggering stock_scores."
                        )

            return True, ""
        except Exception as e:
            logger.error(f"Error validating stock_scores dependencies: {e}")
            return False, f"Failed to validate dependencies: {e}"

    def handle(self, event: dict[str, Any], context: Any) -> LambdaResponse:
        """Handle loader trigger request.

        Event params:
          - loader_name: (required) 'stock_prices_daily', 'market_health_daily', etc.
          - task_count: (optional, default 1) how many parallel tasks
        """
        loader_name = event.get("loader_name")
        if not loader_name:
            path_params = event.get("pathParameters")
            loader_name = path_params.get("loader") if path_params is not None and isinstance(path_params, dict) else None

        if not loader_name:
            return LambdaResponse.validation_error("loader_name", "loader_name is required")

        task_count_raw = event.get("task_count")
        if task_count_raw is None:
            task_count = int(os.getenv("DEFAULT_LOADER_TASK_COUNT", "1"))
        else:
            try:
                task_count = int(task_count_raw)
                if task_count < 1:
                    return LambdaResponse.validation_error("task_count", "task_count must be >= 1")
            except (ValueError, TypeError):
                return LambdaResponse.validation_error(
                    "task_count",
                    f"task_count must be numeric, got {task_count_raw!r}",
                )

        project_name = os.getenv("PROJECT_NAME", "algo")
        cluster_arn = os.getenv("ECS_CLUSTER_ARN")

        if not cluster_arn:
            return LambdaResponse.error("ECS_CLUSTER_ARN not configured", status_code=500)

        critical_loaders = {
            # Metric loaders (required before stock_scores)
            "quality_metrics", "growth_metrics", "value_metrics", "positioning_metrics", "stability_metrics",
            # Price data (fundamental for downstream processing)
            "stock_prices_daily", "price_daily", "price_weekly", "price_monthly",
            "etf_price_daily", "etf_price_weekly", "etf_price_monthly",
            # Market and regime (trading decisions)
            "market_health_daily", "market_exposure_daily",
            # Signals and scoring (position sizing)
            "signals_daily", "stock_scores", "swing_trader_scores", "technical_data_daily",
            # Portfolio and risk metrics
            "algo_metrics_daily", "algo_risk_daily", "economic_metrics_daily",
        }
        # Use FARGATE for critical loaders (higher timeout, guaranteed resources)
        use_fargate = loader_name in critical_loaders

        # Set environment variables for ECS task
        environment_overrides = {
            # Metric loaders need extended timeout (600s = 10 min for yfinance + SEC filings)
            "LOADER_TIMEOUT_SEC": "600" if loader_name in {"quality_metrics", "growth_metrics", "value_metrics", "positioning_metrics", "stability_metrics"} else "300",
            # Reduce batch size in AWS to avoid yfinance rate limiting
            "LOADER_CHUNK_SIZE": "100",
            # Increase memory limit flag for batch processing
            "ECS_TASK_MEMORY_LIMIT": "1024" if loader_name in critical_loaders else "512",
        }

        # Validate dependencies before triggering stock_scores
        if loader_name == "stock_scores":
            is_valid, error_msg = self._validate_stock_scores_dependencies()
            if not is_valid:
                return LambdaResponse.validation_error(
                    "stock_scores",
                    f"Cannot trigger stock_scores: {error_msg}"
                )

        task_def = f"{project_name}-{loader_name}-loader"
        logger.info(f"Triggering loader: {loader_name} (task_def={task_def}, count={task_count})")

        # Build container overrides to pass environment variables to ECS task
        container_overrides = [
            {
                "name": f"{project_name}-{loader_name}-loader",
                "environment": [
                    {"name": k, "value": v}
                    for k, v in environment_overrides.items()
                ],
            }
        ]

        run_task_params: dict[str, Any] = {
            "cluster": cluster_arn,
            "taskDefinition": task_def,
            "networkConfiguration": {
                "awsvpcConfiguration": {
                    "subnets": os.getenv("SUBNET_IDS", "").split(","),
                    "securityGroups": [os.getenv("SECURITY_GROUP_ID", "")],
                    "assignPublicIp": "DISABLED",
                }
            },
            "count": task_count,
            "overrides": {
                "containerOverrides": container_overrides,
            },
        }

        if use_fargate:
            run_task_params["launchType"] = "FARGATE"
        else:
            run_task_params["capacityProviderStrategy"] = [
                {"capacityProvider": "FARGATE_SPOT", "weight": 100, "base": 0}
            ]

        ecs = boto3.client("ecs", region_name=os.getenv("AWS_REGION", "us-east-1"))
        response = ecs.run_task(**run_task_params)

        # CRITICAL: Never silently default task/failure lists from ECS response
        # If "tasks" field missing, ECS returned error response but we need to see it
        tasks = response.get("tasks")
        if tasks is None:
            logger.error(
                f"[TRIGGER_LOADER] ECS run_task response missing 'tasks' field. "
                f"Response structure: {response.keys()}. This indicates ECS API error."
            )
            return LambdaResponse.error(
                "ECS API error: missing 'tasks' field in response. Check AWS credentials and permissions.",
                status_code=500,
            )

        if not tasks:  # tasks is empty list (no tasks started)
            failures = response.get("failures")
            if failures is None:
                logger.error(
                    f"[TRIGGER_LOADER] ECS run_task failed (empty tasks) but 'failures' field missing. "
                    f"Response structure: {response.keys()}. Cannot determine failure reason."
                )
                return LambdaResponse.error(
                    "ECS returned empty tasks list but no failure details. Check AWS CloudWatch logs.",
                    status_code=500,
                )

            error_reasons = []
            for f in failures:
                if isinstance(f, dict) and "reason" in f:
                    error_reasons.append(f["reason"])
                else:
                    error_reasons.append(f"Malformed failure object: {f}")

            if not error_reasons:
                error_reasons = ["Unknown error - empty failures list"]

            return LambdaResponse.error(
                f"Failed to start task: {', '.join(error_reasons)}",
                status_code=500,
            )

        task_arns = [t["taskArn"] for t in tasks]
        logger.info(f"✓ Started {len(task_arns)} tasks: {task_arns}")

        return LambdaResponse.success(
            {
                "message": f"Triggered {loader_name} loader",
                "tasks": task_arns,
                "timestamp": datetime.now(timezone.utc).isoformat(),
            }
        )


lambda_handler = create_lambda_handler(TriggerLoadersHandler)
