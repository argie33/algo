"""
SAM CLI version
"""

__version__ = "1.142.0"
